
Application Definition
======================

.. autoclass:: spyne.application.Application
    :members:
    :inherited-members:

.. autofunction:: spyne.application.return_traceback_in_unhandled_exceptions
