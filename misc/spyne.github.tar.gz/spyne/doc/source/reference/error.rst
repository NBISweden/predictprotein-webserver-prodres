
Common Exceptions
=================

.. automodule:: spyne.error
    :members:
    :show-inheritance:
