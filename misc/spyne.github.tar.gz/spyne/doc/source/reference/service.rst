
Service Definition
==================

.. automodule:: spyne.service
    :members:
    :inherited-members:

