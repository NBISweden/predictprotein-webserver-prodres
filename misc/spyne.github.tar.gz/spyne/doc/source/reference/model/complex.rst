
.. _reference-model-complex:

Complex
-------

.. automodule:: spyne.model.complex
   :members:
   :show-inheritance:

.. function:: TTableModel(metadata=None)

   A TableModel template that generates a new TableModel class for each
   call. If metadata is not supplied, a new one is instantiated.
