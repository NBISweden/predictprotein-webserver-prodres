
.. _reference-model-binary:

Binary Types
------------

.. automodule:: spyne.model.binary

.. autoclass:: spyne.model.binary.ByteArray
   :members:
   :show-inheritance:

.. autoclass:: spyne.model.binary.File
   :members:
   :show-inheritance:
