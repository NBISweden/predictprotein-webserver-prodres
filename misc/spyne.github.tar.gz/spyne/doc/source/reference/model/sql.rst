
.. _reference-model-persistance:

Persisting Objects
------------------

.. automodule:: spyne.model.table
   :members:
   :show-inheritance:
