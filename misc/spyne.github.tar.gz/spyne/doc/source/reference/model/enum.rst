
.. _reference-model-enum:

Enum
----

.. autofunction:: spyne.model.enum.Enum

