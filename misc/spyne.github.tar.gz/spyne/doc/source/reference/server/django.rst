
.. _reference-server-django:
.. _spyne.server.django:

Http (Django)
-------------

.. automodule:: spyne.server.django
    :members:
    :inherited-members:
    :undoc-members:
