
.. _reference-protocol-base:

Protocol Base Class
--------------------

.. automodule:: spyne.protocol._base
    :members:
    :show-inheritance:

